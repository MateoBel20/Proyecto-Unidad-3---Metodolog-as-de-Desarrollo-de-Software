﻿**SISTEMA HELADERÍA**

Un ejemplo basado en la heladería “ICE-CREAM FAVÁN”, Cuenta con diferentes tipos de interfaces como, iniciar sesión, menú principal, clientes, personal administrativo, factura y reportes.

Cuenta con una base de datos sqlite3, reportlab y pyqt5.

**Sqlite**

Los sistemas de gestión de bases de datos cliente-servidor, el motor de SQLite no es un proceso independiente con el que el programa principal se comunica. En lugar de eso, la biblioteca SQLite se enlaza con el programa pasando a ser parte integral del mismo. El programa utiliza la funcionalidad de SQLite a través de llamadas simples a subrutinas y funciones.

**Reportlab**

Es una librería muy extensa y con muchas funcionalidades, desde pequeños textos y figuras geométricas a grandes gráficos e ilustraciones, todo ello puede ser incluido dentro de un PDF. ReportLab es el motor de código abierto, ultra robusto y de gran duración para crear documentos PDF complejos y basados ​​en datos y gráficos vectoriales personalizados. Es gratis, de código abierto y escrito en Python.

**Pyqt5**

PyQt5 es un conjunto completo de enlaces de Python para Qt v5. Se implementa como más de 35 módulos de extensión y permite que Python se utilice como un lenguaje de desarrollo de aplicaciones alternativo a C ++ en todas las plataformas compatibles, incluidas iOS y Android.
